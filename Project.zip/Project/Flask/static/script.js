// Add your desired JavaScript code here

// Example: Display a confirmation message on successful registration
const registerForm = document.querySelector('#register-form');
if (registerForm) {
    registerForm.addEventListener('submit', function (event) {
        event.preventDefault();
        // Perform form submission via AJAX or other method
        // If successful, display a confirmation message
        alert('Registration successful!');
        // Optionally redirect to a different page
        // window.location.href = '/model';
    });
}

// Example: Display an error message on incorrect login
const loginForm = document.querySelector('#login-form');
if (loginForm) {
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();
        // Perform form submission via AJAX or other method
        // If login fails, display an error message
        alert('Incorrect email/password. Please try again.');
    });
}
